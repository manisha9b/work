<?php
//$database->clusterId;
?>

<div class="col-md-6">
	<div class="panel">
		<div class="panel-heading">
			<h6 class="panel-title text-primary">
				<i class="fa fa-bar-chart-o"></i> Package Invited <span class="small"></span>
			</h6>
		</div>
		<div class="panel-body">
		  	<div id="abc"></div>
		</div>
	</div>	
</div>

<div class="col-md-4">
	<div class="panel">
		<div class="panel-heading">
			<h4 class="panel-title text-primary">
				<i class="fa fa-bar-chart-o"></i> Appointment Confirmed <span class="small"></span>
			</h4>
		</div>
		<div class="panel-body">
		  <!--<div id="graphDonut2"></div>-->
		</div>
	</div>
</div>

<div class="col-md-4">
	<div class="panel">
		<div class="panel-heading">
			<h4 class="panel-title text-primary">
				<i class="fa fa-bar-chart-o"></i> Employee/Users Visited <span class="small"></span>
			</h4>
		</div>
		<div class="panel-body">
		  <!--<div id="graphDonut2"></div>-->
		</div>
	</div>
</div>


