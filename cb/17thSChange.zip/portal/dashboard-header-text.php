<div class="welcome-txt">
<!--
<?php
echo $_SESSION['ref_id']."\n";
echo $database->clusterId."\n";
?>
!-->


<h4>Hi! <? echo $_SESSION['user_display_name']; ?>,<br />Welcome to the EasyBuyHealth HR Control Panel</h4>
</div>